<h1 align="left">python-template</h1>

<p align="left">
  Here you should add general information about the project
  <br> 
</p>

## 📝 Table of Contents

- [📝 Table of Contents](#-table-of-contents)
- [🧐 About ](#-about-)
- [👨‍💻 Description ](#-description-)
- [🏁 Getting Started ](#-getting-started-)
  - [Installing](#installing)
  - [Usage](#usage)
- [⛏️ Built Using ](#️-built-using-)
- [✍️ Authors ](#️-authors-)

## 🧐 About <a name = "about"></a>

This is a general template for any Python project you want to start working on.

*Here you can add 1-2 paragraphs on information about the project*

## 👨‍💻 Description <a name = "description"></a>

*Here you can add a description for your project and its purpose*

## 🏁 Getting Started <a name = "getting_started"></a>

### Installing

*Here you can add a description on how to install the project*

### Usage

*Here you can add a description on how to run and use the project*


## ⛏️ Built Using <a name = "built_using"></a>

*Here you can link the packages/modules/dependencies used to build your project*

## ✍️ Authors <a name = "authors"></a>

*Here you can add a list of authors/people who worked and maintain the project*

- [@abshir](https://github.com/abshir112) - Idea & Initial work
- [@Lakshmi](https://github.com/lakshmivishal9496 ) - Idea & Initial work